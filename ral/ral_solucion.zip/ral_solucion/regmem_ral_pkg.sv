// ============================================================================
// regmem_ral_pkg.sv
// Tutorial: el RAL de UVM desde cero - Sección 7
//
// Modelo de registros y memoria de regmem_dut.
// ============================================================================
`timescale 1ns/1ps
package regmem_ral_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // ------------------------------------------------------------ CTRL @ 0x00
  class ctrl_reg extends uvm_reg;
    `uvm_object_utils(ctrl_reg)
    rand uvm_reg_field EN;
    rand uvm_reg_field MODE;
    rand uvm_reg_field IRQ_EN;
    rand uvm_reg_field PRESCALER;

    // La especificación prohíbe PRESCALER = 0
    constraint c_presc { PRESCALER.value != 0; }

    function new(string name = "ctrl_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      EN        = uvm_reg_field::type_id::create("EN");
      MODE      = uvm_reg_field::type_id::create("MODE");
      IRQ_EN    = uvm_reg_field::type_id::create("IRQ_EN");
      PRESCALER = uvm_reg_field::type_id::create("PRESCALER");
      //                   parent size lsb  acc   vol reset  has_rst rand indiv
      EN.configure       (this,  1,   0, "RW",  0,  1'b0,  1,      1,   0);
      MODE.configure     (this,  2,   1, "RW",  0,  2'h0,  1,      1,   0);
      IRQ_EN.configure   (this,  1,   3, "RW",  0,  1'b0,  1,      1,   0);
      PRESCALER.configure(this,  8,   8, "RW",  0,  8'h01, 1,      1,   1);
    endfunction
  endclass

  // ------------------------------------------------------------ STATUS @ 0x04
  class status_reg extends uvm_reg;
    `uvm_object_utils(status_reg)
    uvm_reg_field BUSY;
    uvm_reg_field DONE;
    uvm_reg_field ERR_CNT;

    function new(string name = "status_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      BUSY    = uvm_reg_field::type_id::create("BUSY");
      DONE    = uvm_reg_field::type_id::create("DONE");
      ERR_CNT = uvm_reg_field::type_id::create("ERR_CNT");
      // Campos RO volátiles: los cambia el hardware
      BUSY.configure   (this, 1, 0, "RO", 1, 1'b0, 1, 0, 0);
      DONE.configure   (this, 1, 1, "RO", 1, 1'b0, 1, 0, 0);
      ERR_CNT.configure(this, 8, 4, "RO", 1, 8'h0, 1, 0, 0);
    endfunction
  endclass

  // ------------------------------------------------------------ INT_STAT @ 0x08
  class int_stat_reg extends uvm_reg;
    `uvm_object_utils(int_stat_reg)
    uvm_reg_field DONE_IRQ;
    uvm_reg_field ERR_IRQ;

    function new(string name = "int_stat_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      DONE_IRQ = uvm_reg_field::type_id::create("DONE_IRQ");
      ERR_IRQ  = uvm_reg_field::type_id::create("ERR_IRQ");
      // W1C volátiles: el hardware los pone a 1, el software los borra
      DONE_IRQ.configure(this, 1, 0, "W1C", 1, 1'b0, 1, 0, 0);
      ERR_IRQ.configure (this, 1, 1, "W1C", 1, 1'b0, 1, 0, 0);
    endfunction
  endclass

  // ------------------------------------------------------------ CMD @ 0x0C
  class cmd_reg extends uvm_reg;
    `uvm_object_utils(cmd_reg)
    rand uvm_reg_field OPCODE;

    function new(string name = "cmd_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      OPCODE = uvm_reg_field::type_id::create("OPCODE");
      OPCODE.configure(this, 4, 0, "WO", 0, 4'h0, 1, 1, 0);
    endfunction
  endclass

  // ------------------------------------------------------------ SCRATCH @ 0x10
  class scratch_reg extends uvm_reg;
    `uvm_object_utils(scratch_reg)
    rand uvm_reg_field DATA;

    function new(string name = "scratch_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      DATA = uvm_reg_field::type_id::create("DATA");
      DATA.configure(this, 32, 0, "RW", 0, 32'h0, 1, 1, 1);
    endfunction
  endclass

  // ------------------------------------------------------------ ID @ 0x14
  class id_reg extends uvm_reg;
    `uvm_object_utils(id_reg)
    uvm_reg_field VALUE;

    function new(string name = "id_reg");
      super.new(name, 32, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      VALUE = uvm_reg_field::type_id::create("VALUE");
      VALUE.configure(this, 32, 0, "RO", 0, 32'h5A5A_0001, 1, 0, 0);
    endfunction
  endclass

  // ------------------------------------------------------------ BUF @ 0x80
  class buf_mem extends uvm_mem;
    `uvm_object_utils(buf_mem)
    function new(string name = "buf_mem");
      super.new(name, 32, 32, "RW", UVM_NO_COVERAGE);
    endfunction
  endclass

  // ------------------------------------------------------------ Bloque
  class regmem_reg_block extends uvm_reg_block;
    `uvm_object_utils(regmem_reg_block)
    rand ctrl_reg     CTRL;
    rand status_reg   STATUS;
    rand int_stat_reg INT_STAT;
    rand cmd_reg      CMD;
    rand scratch_reg  SCRATCH;
    rand id_reg       ID;
    buf_mem           BUF;

    function new(string name = "regmem_reg_block");
      super.new(name, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      // ---- Registros: crear, configurar, construir, rutas HDL
      CTRL = ctrl_reg::type_id::create("CTRL");
      CTRL.configure(this, null, "");
      CTRL.build();
      CTRL.add_hdl_path_slice("en_q",     0, 1);
      CTRL.add_hdl_path_slice("mode_q",   1, 2);
      CTRL.add_hdl_path_slice("irq_en_q", 3, 1);
      CTRL.add_hdl_path_slice("presc_q",  8, 8);

      STATUS = status_reg::type_id::create("STATUS");
      STATUS.configure(this, null, "");
      STATUS.build();
      STATUS.add_hdl_path_slice("busy_q",    0, 1);
      STATUS.add_hdl_path_slice("done_q",    1, 1);
      STATUS.add_hdl_path_slice("err_cnt_q", 4, 8);

      INT_STAT = int_stat_reg::type_id::create("INT_STAT");
      INT_STAT.configure(this, null, "");
      INT_STAT.build();
      INT_STAT.add_hdl_path_slice("int_stat_q", 0, 2);

      CMD = cmd_reg::type_id::create("CMD");
      CMD.configure(this, null, "");          // sin ruta HDL: no tiene almacenamiento
      CMD.build();

      SCRATCH = scratch_reg::type_id::create("SCRATCH");
      SCRATCH.configure(this, null, "scratch_q");   // ruta que cubre todo el registro
      SCRATCH.build();

      ID = id_reg::type_id::create("ID");
      ID.configure(this, null, "id_w");
      ID.build();

      // ---- Memoria
      BUF = buf_mem::type_id::create("BUF");
      BUF.configure(this, "mem");

      // ---- Mapa: base 0, bus de 4 bytes, little endian, direcciones en bytes
      default_map = create_map("default_map", 'h0, 4, UVM_LITTLE_ENDIAN, 1);
      default_map.add_reg(CTRL,     'h00, "RW");
      default_map.add_reg(STATUS,   'h04, "RO");
      default_map.add_reg(INT_STAT, 'h08, "RW");
      default_map.add_reg(CMD,      'h0C, "RW");
      default_map.add_reg(SCRATCH,  'h10, "RW");
      default_map.add_reg(ID,       'h14, "RO");
      default_map.add_mem(BUF,      'h80, "RW");
    endfunction
  endclass
endpackage
