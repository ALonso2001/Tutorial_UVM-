// ============================================================================
// regmem_env_pkg.sv
// Tutorial: el RAL de UVM desde cero - Secciones 7 a 11
//
// Contenido:
//   apb_reg_adapter        Adaptador (Sección 8.2)
//   regmem_env             Env con modelo, adaptador y predictor (8.4, 9.4)
//   regmem_base_seq        Secuencia base de registros (10.1)
//   step1_seq..step9_seq   Pasos del tutorial de accesos (10)
//   model_check_test       Punto de control del modelo (7)
//   predictor_test         Experimento implícito/explícito (8.5)
//   ral_test               Test que ejecuta el paso +STEP=n (10.1)
//   builtin_test           Secuencias predefinidas de UVM (11)
// ============================================================================
`timescale 1ns/1ps
package regmem_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import apb_pkg::*;
  import regmem_ral_pkg::*;

  // ==========================================================================
  // Adaptador (Sección 8.2)
  // ==========================================================================
  class apb_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(apb_reg_adapter)

    function new(string name = "apb_reg_adapter");
      super.new(name);
      supports_byte_enable = 0;   // APB3 no tiene byte enables
      provides_responses   = 0;   // el driver escribe el dato leído en el propio item
    endfunction

    // Modelo -> bus
    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
      apb_item item = apb_item::type_id::create("item");
      item.write = (rw.kind == UVM_WRITE);
      item.addr  = rw.addr[7:0];
      item.data  = (rw.kind == UVM_WRITE) ? rw.data[31:0] : 32'h0;
      `uvm_info("ADAPT", {"reg2bus: ", item.convert2string()}, UVM_HIGH)
      return item;
    endfunction

    // Bus -> modelo (lo usan el mapa, tras cada acceso, y el predictor)
    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
      apb_item item;
      if (!$cast(item, bus_item)) begin
        `uvm_fatal("ADAPT", "bus2reg recibió un item que no es apb_item")
        return;
      end
      rw.kind    = item.write ? UVM_WRITE : UVM_READ;
      rw.addr    = item.addr;
      rw.data    = item.data;
      rw.n_bits  = 32;
      rw.byte_en = '1;
      rw.status  = UVM_IS_OK;      // con PSLVERR: item.slverr ? UVM_NOT_OK : UVM_IS_OK
    endfunction
  endclass

  // ==========================================================================
  // Env (Secciones 8.4 y 9.4)
  // ==========================================================================
  class regmem_env extends uvm_env;
    `uvm_component_utils(regmem_env)
    apb_agent                     agt;
    regmem_reg_block              rm;
    apb_reg_adapter               adapter;
    uvm_reg_predictor #(apb_item) predictor;

    // Ponga a 1 (desde el test, antes de crear el env) para usar predicción implícita
    bit use_auto_predict = 0;

    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agt = apb_agent::type_id::create("agt", this);
      // El test puede pasar un modelo ya construido; si no, lo construimos aquí
      if (!uvm_config_db #(regmem_reg_block)::get(this, "", "rm", rm)) begin
        rm = regmem_reg_block::type_id::create("rm");
        rm.build();
        rm.set_hdl_path_root("tb_top.dut");
        rm.lock_model();
        rm.reset();
      end
      void'(uvm_config_db #(bit)::get(this, "", "use_auto_predict", use_auto_predict));
      adapter   = apb_reg_adapter::type_id::create("adapter");
      predictor = uvm_reg_predictor #(apb_item)::type_id::create("predictor", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      uvm_reg_backdoor bk;
      super.connect_phase(phase);
      // Frontdoor: el mapa usa el secuenciador del agente a través del adaptador
      rm.default_map.set_sequencer(agt.sqr, adapter);

      if (use_auto_predict) begin
        // Predicción implícita (solo para el experimento de la Sección 8.5)
        rm.default_map.set_auto_predict(1);
      end
      else begin
        // Predicción explícita (recomendada)
        rm.default_map.set_auto_predict(0);
        predictor.map     = rm.default_map;
        predictor.adapter = adapter;
        agt.mon.ap.connect(predictor.bus_in);
      end

      // Backdoor de usuario para SCRATCH, si tb_top lo ha publicado (Sección 9.4)
      if (uvm_config_db #(uvm_reg_backdoor)::get(this, "", "scratch_bkdr", bk))
        rm.SCRATCH.set_backdoor(bk);
    endfunction
  endclass

  // ==========================================================================
  // Secuencia base (Sección 10.1)
  // ==========================================================================
  class regmem_base_seq extends uvm_reg_sequence;
    `uvm_object_utils(regmem_base_seq)
    regmem_reg_block rm;
    uvm_status_e     status;
    uvm_reg_data_t   value;
    function new(string name = "regmem_base_seq"); super.new(name); endfunction

    virtual task pre_start();
      super.pre_start();
      if (!$cast(rm, model)) `uvm_fatal("SEQ", "model no es un regmem_reg_block")
    endtask

    // Ayuda: comprueba el estado de cada acceso
    function void check_ok(string what);
      if (status != UVM_IS_OK) `uvm_error("SEQ", {what, ": status distinto de UVM_IS_OK"})
    endfunction
  endclass

  // ==========================================================================
  // Paso 1: escritura y lectura por frontdoor
  // ==========================================================================
  class step1_seq extends regmem_base_seq;
    `uvm_object_utils(step1_seq)
    function new(string name = "step1_seq"); super.new(name); endfunction
    task body();
      // EN = 1, MODE = 2, IRQ_EN = 0, PRESCALER = 3
      rm.CTRL.write(status, 32'h0000_0305, .parent(this));
      check_ok("write CTRL");
      rm.CTRL.read(status, value, .parent(this));
      check_ok("read CTRL");
      `uvm_info("STEP1", $sformatf("CTRL leído = 0x%08h", value), UVM_LOW)
      rm.ID.read(status, value, .parent(this));
      `uvm_info("STEP1", $sformatf("ID leído   = 0x%08h", value), UVM_LOW)
    endtask
  endclass

  // ==========================================================================
  // Paso 2: el espejo y mirror
  // ==========================================================================
  class step2_seq extends regmem_base_seq;
    `uvm_object_utils(step2_seq)
    function new(string name = "step2_seq"); super.new(name); endfunction
    task body();
      rm.CTRL.write(status, 32'h0000_0305, .parent(this));
      `uvm_info("STEP2", $sformatf("Espejo de CTRL: 0x%08h", rm.CTRL.get_mirrored_value()), UVM_LOW)
      `uvm_info("STEP2", $sformatf("Espejo de MODE: %0d", rm.CTRL.MODE.get_mirrored_value()), UVM_LOW)

      // Comprobación que pasa: el DUT coincide con el espejo
      rm.CTRL.mirror(status, UVM_CHECK, .parent(this));

      // El "hardware" cambia PRESCALER a espaldas del modelo
      void'(uvm_hdl_deposit("tb_top.dut.presc_q", 8'h07));

      // Comprobación que falla (UVM_ERROR esperado) y actualiza el espejo
      rm.CTRL.mirror(status, UVM_CHECK, .parent(this));
      `uvm_info("STEP2", $sformatf("Espejo tras mirror: 0x%08h", rm.CTRL.get_mirrored_value()), UVM_LOW)
    endtask
  endclass

  // ==========================================================================
  // Paso 3: backdoor, peek y poke
  // ==========================================================================
  class step3_seq extends regmem_base_seq;
    `uvm_object_utils(step3_seq)
    function new(string name = "step3_seq"); super.new(name); endfunction
    task body();
      // a) Escritura por backdoor, lectura por frontdoor
      rm.SCRATCH.write(status, 32'hCAFE_F00D, UVM_BACKDOOR, .parent(this));
      rm.SCRATCH.read (status, value, UVM_FRONTDOOR, .parent(this));
      `uvm_info("STEP3", $sformatf("a) SCRATCH por frontdoor = 0x%08h", value), UVM_LOW)

      // b) Escritura por frontdoor, lectura por backdoor
      rm.CTRL.write(status, 32'h0000_0A0B, .parent(this));
      rm.CTRL.read (status, value, UVM_BACKDOOR, .parent(this));
      `uvm_info("STEP3", $sformatf("b) CTRL por backdoor = 0x%08h", value), UVM_LOW)

      // c) poke frente a write por backdoor en un registro W1C
      rm.INT_STAT.poke(status, 32'h3, .parent(this));                  // valor crudo: ambos flags a 1
      rm.INT_STAT.write(status, 32'h1, UVM_BACKDOOR, .parent(this));   // emula W1C: borra DONE_IRQ
      rm.INT_STAT.peek(status, value, .parent(this));
      `uvm_info("STEP3", $sformatf("c) INT_STAT tras write backdoor = 0x%0h", value), UVM_LOW)
      rm.INT_STAT.poke(status, 32'h1, .parent(this));                  // valor crudo
      rm.INT_STAT.peek(status, value, .parent(this));
      `uvm_info("STEP3", $sformatf("c) INT_STAT tras poke 1        = 0x%0h", value), UVM_LOW)

      // d) Backdoor imposible: CMD no tiene ruta HDL (UVM_ERROR esperado)
      rm.CMD.read(status, value, UVM_BACKDOOR, .parent(this));
      `uvm_info("STEP3", $sformatf("d) status de CMD por backdoor = %s", status.name()), UVM_LOW)
    endtask
  endclass

  // ==========================================================================
  // Paso 4: valor deseado, set, randomize y update
  // ==========================================================================
  class step4_seq extends regmem_base_seq;
    `uvm_object_utils(step4_seq)
    function new(string name = "step4_seq"); super.new(name); endfunction
    task body();
      // a) Cambiar el valor deseado campo a campo y escribir solo si hace falta
      rm.CTRL.EN.set(1);
      rm.CTRL.MODE.set(3);
      rm.CTRL.PRESCALER.set(8'h10);
      `uvm_info("STEP4", $sformatf("deseado=0x%08h espejo=0x%08h needs_update=%0d",
                rm.CTRL.get(), rm.CTRL.get_mirrored_value(), rm.CTRL.needs_update()), UVM_LOW)
      rm.CTRL.update(status, .parent(this));   // escribe 0x1007
      rm.CTRL.update(status, .parent(this));   // ya coincide: no hace nada

      // b) Aleatorizar respetando restricciones y actualizar
      if (!rm.CTRL.randomize() with { MODE.value != 0; })
        `uvm_error("STEP4", "randomize de CTRL falló")
      rm.CTRL.update(status, .parent(this));
      rm.CTRL.mirror(status, UVM_CHECK, .parent(this));

      // c) Aleatorizar y actualizar todo el bloque, sin tocar el registro de comando
      rm.CMD.OPCODE.rand_mode(0);
      if (!rm.randomize()) `uvm_error("STEP4", "randomize del bloque falló")
      rm.update(status, .parent(this));
    endtask
  endclass

  // ==========================================================================
  // Paso 5: acceso a campos
  // ==========================================================================
  class step5_seq extends regmem_base_seq;
    `uvm_object_utils(step5_seq)
    function new(string name = "step5_seq"); super.new(name); endfunction
    task body();
      rm.CTRL.write(status, 32'h0000_0305, .parent(this));
      // Escribir solo MODE: el bus no tiene byte enables y MODE no ocupa un byte completo
      rm.CTRL.MODE.write(status, 2'b11, .parent(this));
      rm.CTRL.read(status, value, .parent(this));
      `uvm_info("STEP5", $sformatf("CTRL tras escribir MODE = 0x%08h", value), UVM_LOW)
      // Leer un campo
      rm.CTRL.PRESCALER.read(status, value, .parent(this));
      `uvm_info("STEP5", $sformatf("PRESCALER = 0x%02h", value), UVM_LOW)
    endtask
  endclass

  // ==========================================================================
  // Paso 6: políticas de acceso en acción
  // ==========================================================================
  class step6_seq extends regmem_base_seq;
    `uvm_object_utils(step6_seq)
    function new(string name = "step6_seq"); super.new(name); endfunction
    task body();
      // Habilitar y lanzar una operación válida
      rm.CTRL.write(status, 32'h0000_0101, .parent(this));
      rm.CMD.write (status, 32'h1, .parent(this));
      // Sondear BUSY (campo RO volátil)
      do rm.STATUS.read(status, value, .parent(this));
      while (value[0]);
      `uvm_info("STEP6", $sformatf("STATUS = 0x%08h (DONE=%0d)", value, value[1]), UVM_LOW)

      // Flag de interrupción y borrado W1C
      rm.INT_STAT.read(status, value, .parent(this));
      `uvm_info("STEP6", $sformatf("INT_STAT = 0x%0h", value), UVM_LOW)
      rm.INT_STAT.write(status, 32'h1, .parent(this));
      `uvm_info("STEP6", $sformatf("Espejo INT_STAT tras W1C = 0x%0h", rm.INT_STAT.get_mirrored_value()), UVM_LOW)
      rm.INT_STAT.read(status, value, .parent(this));
      `uvm_info("STEP6", $sformatf("INT_STAT leído = 0x%0h", value), UVM_LOW)

      // Comando inválido: contador de errores
      rm.CMD.write(status, 32'hF, .parent(this));
      rm.STATUS.read(status, value, .parent(this));
      `uvm_info("STEP6", $sformatf("ERR_CNT = %0d", rm.STATUS.ERR_CNT.get_mirrored_value()), UVM_LOW)

      // Leer un registro WO y comprobar una constante
      rm.CMD.read(status, value, .parent(this));
      `uvm_info("STEP6", $sformatf("CMD leído = 0x%0h, espejo = 0x%0h", value, rm.CMD.get_mirrored_value()), UVM_LOW)
      rm.ID.mirror(status, UVM_CHECK, .parent(this));
    endtask
  endclass

  // ==========================================================================
  // Paso 7: memoria por frontdoor y backdoor
  // ==========================================================================
  class step7_seq extends regmem_base_seq;
    `uvm_object_utils(step7_seq)
    function new(string name = "step7_seq"); super.new(name); endfunction
    task body();
      uvm_reg_data_t wr_data[];
      uvm_reg_data_t rd_data[];
      wr_data = '{32'h0000_0010, 32'h0000_0020, 32'h0000_0030, 32'h0000_0040};

      // a) Escritura frontdoor, lectura backdoor
      rm.BUF.write(status, 5, 32'h1111_2222, .parent(this));
      rm.BUF.read (status, 5, value, UVM_BACKDOOR, .parent(this));
      `uvm_info("STEP7", $sformatf("a) BUF[5] por backdoor = 0x%08h", value), UVM_LOW)

      // b) poke y lectura frontdoor
      rm.BUF.poke(status, 6, 32'hDEAD_BEEF, .parent(this));
      rm.BUF.read(status, 6, value, .parent(this));
      `uvm_info("STEP7", $sformatf("b) BUF[6] por frontdoor = 0x%08h", value), UVM_LOW)

      // c) Ráfagas
      rm.BUF.burst_write(status, 8, wr_data, .parent(this));
      rm.BUF.burst_read (status, 8, rd_data, .parent(this));
      foreach (rd_data[i])
        `uvm_info("STEP7", $sformatf("c) BUF[%0d] = 0x%08h", 8 + i, rd_data[i]), UVM_LOW)

      // d) Inicializar toda la memoria por backdoor (instantáneo)
      for (longint unsigned i = 0; i < rm.BUF.get_size(); i++)
        rm.BUF.poke(status, i, 64'hA000_0000 + i, .parent(this));
      rm.BUF.read(status, 31, value, .parent(this));
      `uvm_info("STEP7", $sformatf("d) BUF[31] = 0x%08h", value), UVM_LOW)
    endtask
  endclass

  // ==========================================================================
  // Paso 8: aislar un error con frontdoor y backdoor (compilar con +define+BUG_SCRATCH)
  // ==========================================================================
  class step8_seq extends regmem_base_seq;
    `uvm_object_utils(step8_seq)
    function new(string name = "step8_seq"); super.new(name); endfunction
    task body();
      uvm_reg_data_t fd, bd;
      // Prueba 1: escribir por el bus, mirar el almacenamiento
      rm.SCRATCH.write(status, 32'h8000_0001, .parent(this));
      rm.SCRATCH.peek(status, bd, .parent(this));
      // Prueba 2: escribir el almacenamiento, leer por el bus
      rm.SCRATCH.poke(status, 32'h8000_0001, .parent(this));
      rm.SCRATCH.read(status, fd, .parent(this));
      `uvm_info("STEP8", $sformatf("write bus -> peek = 0x%08h | poke -> read bus = 0x%08h", bd, fd), UVM_LOW)
      if (bd != 32'h8000_0001 && fd == 32'h8000_0001)
        `uvm_error("STEP8", "Fallo en el camino de ESCRITURA del bus")
      else if (bd == 32'h8000_0001 && fd != 32'h8000_0001)
        `uvm_error("STEP8", "Fallo en el camino de LECTURA del bus")
    endtask
  endclass

  // ==========================================================================
  // Paso 9: predict y reset del modelo
  // ==========================================================================
  class step9_seq extends regmem_base_seq;
    `uvm_object_utils(step9_seq)
    function new(string name = "step9_seq"); super.new(name); endfunction
    task body();
      // predict(): informar al modelo de un cambio conocido sin acceder al DUT
      void'(uvm_hdl_deposit("tb_top.dut.scratch_q", 32'h0000_BEEF));
      void'(rm.SCRATCH.predict(32'h0000_BEEF));
      rm.SCRATCH.mirror(status, UVM_CHECK, .parent(this));   // pasa: el modelo ya lo sabía

      // reset(): tras un reset del DUT, el modelo debe volver a los valores de reset
      rm.CTRL.write(status, 32'h0000_0F0F, .parent(this));
      rm.reset();
      `uvm_info("STEP9", $sformatf("Espejo de CTRL tras rm.reset() = 0x%08h", rm.CTRL.get_mirrored_value()), UVM_LOW)
      rm.CTRL.mirror(status, UVM_CHECK, .parent(this));      // falla (esperado): el DUT no se ha reseteado
    endtask
  endclass

  // ==========================================================================
  // Punto de control del modelo (Sección 7)
  // ==========================================================================
  class model_check_test extends uvm_test;
    `uvm_component_utils(model_check_test)
    regmem_reg_block rm;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      rm = regmem_reg_block::type_id::create("rm");
      rm.build();
      rm.lock_model();
      rm.reset();
    endfunction

    function void end_of_elaboration_phase(uvm_phase phase);
      uvm_reg regs[$];
      uvm_reg r;
      rm.get_registers(regs);
      foreach (regs[i])
        `uvm_info("MODEL", $sformatf("%-10s addr=0x%02h reset=0x%08h",
                  regs[i].get_name(), regs[i].get_address(), regs[i].get_reset()), UVM_LOW)
      r = rm.default_map.get_reg_by_offset('h10);
      `uvm_info("MODEL", $sformatf("Registro en 0x10: %s", (r == null) ? "ninguno" : r.get_name()), UVM_LOW)
      `uvm_info("MODEL", $sformatf("BUF: %0d palabras desde 0x%02h",
                rm.BUF.get_size(), rm.BUF.get_address(0)), UVM_LOW)
    endfunction
  endclass

  // ==========================================================================
  // Experimento implícito/explícito (Sección 8.5)
  //   +UVM_TESTNAME=predictor_test                 -> predictor explícito
  //   +UVM_TESTNAME=predictor_test +AUTO_PREDICT   -> predicción implícita
  // ==========================================================================
  class predictor_test extends uvm_test;
    `uvm_component_utils(predictor_test)
    regmem_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if ($test$plusargs("AUTO_PREDICT"))
        uvm_config_db #(bit)::set(this, "env", "use_auto_predict", 1'b1);
      env = regmem_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      apb_raw_write_seq raw;
      uvm_status_e      st;
      phase.raise_objection(this);
      raw = apb_raw_write_seq::type_id::create("raw");
      raw.addr = 'h10;
      raw.data = 32'h1234_5678;
      raw.start(env.agt.sqr);
      #10ns;   // margen para que el monitor publique
      `uvm_info("PRED", $sformatf("Espejo de SCRATCH: 0x%08h", env.rm.SCRATCH.get_mirrored_value()), UVM_LOW)
      env.rm.SCRATCH.mirror(st, UVM_CHECK);
      `uvm_info("PRED", $sformatf("Estado del mirror: %s", st.name()), UVM_LOW)
      phase.drop_objection(this);
    endtask
  endclass

  // ==========================================================================
  // Test que ejecuta el paso indicado con +STEP=n (Sección 10.1)
  // ==========================================================================
  class ral_test extends uvm_test;
    `uvm_component_utils(ral_test)
    regmem_env env;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = regmem_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      int unsigned    step;
      uvm_object      obj;
      regmem_base_seq seq;
      step = 1;
      void'($value$plusargs("STEP=%d", step));
      obj = uvm_factory::get().create_object_by_name($sformatf("step%0d_seq", step), "", "seq");
      if (obj == null || !$cast(seq, obj)) `uvm_fatal("TEST", $sformatf("No existe step%0d_seq", step))
      seq.model = env.rm;
      phase.raise_objection(this);
      seq.start(null);           // una secuencia de registros puede correr sin secuenciador propio
      #50ns;
      phase.drop_objection(this);
    endtask
  endclass

  // ==========================================================================
  // Secuencias predefinidas de UVM (Sección 11)
  // ==========================================================================
  class builtin_test extends ral_test;
    `uvm_component_utils(builtin_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task run_phase(uvm_phase phase);
      uvm_reg_hw_reset_seq      rst_seq;
      uvm_reg_bit_bash_seq      bash_seq;
      uvm_mem_walk_seq          walk_seq;
      uvm_reg_mem_hdl_paths_seq path_seq;

      rst_seq  = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
      bash_seq = uvm_reg_bit_bash_seq::type_id::create("bash_seq");
      walk_seq = uvm_mem_walk_seq::type_id::create("walk_seq");
      path_seq = uvm_reg_mem_hdl_paths_seq::type_id::create("path_seq");

      // CMD lanza operaciones; STATUS e INT_STAT cambian por hardware
      uvm_resource_db #(bit)::set({"REG::", env.rm.CMD.get_full_name()},      "NO_REG_BIT_BASH_TEST", 1, this);
      uvm_resource_db #(bit)::set({"REG::", env.rm.STATUS.get_full_name()},   "NO_REG_BIT_BASH_TEST", 1, this);
      uvm_resource_db #(bit)::set({"REG::", env.rm.INT_STAT.get_full_name()}, "NO_REG_BIT_BASH_TEST", 1, this);

      phase.raise_objection(this);
      path_seq.model = env.rm;  path_seq.start(null);
      rst_seq.model  = env.rm;  rst_seq.start(null);
      bash_seq.model = env.rm;  bash_seq.start(null);
      walk_seq.model = env.rm;  walk_seq.start(null);
      phase.drop_objection(this);
    endtask
  endclass
endpackage
