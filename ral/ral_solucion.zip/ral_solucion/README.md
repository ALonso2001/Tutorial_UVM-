# Tutorial: el RAL de UVM desde cero — archivos de solución

Solución completa del tutorial `tutorial_uvm_ral.html`.

## Archivos

| Archivo | Contenido | Sección del tutorial |
| --- | --- | --- |
| `regmem_dut.sv` | DUT: esclavo APB con 6 registros y una memoria de 32 palabras | 3 |
| `apb_if.sv` | Interfaz APB | 4 |
| `apb_pkg.sv` | Agente APB (item, driver, monitor, secuenciador) y secuencia cruda | 4 |
| `regmem_ral_pkg.sv` | Modelo de registros y memoria | 7 |
| `regmem_env_pkg.sv` | Adaptador, env con predictor, secuencias de los pasos 1 a 9 y todos los tests | 7 a 11 |
| `tb_top.sv` | Reloj, reset, DUT y backdoor de usuario para `SCRATCH` | 4 y 9.4 |
| `Makefile` | Compilación y ejecución en Questa, VCS, Xcelium y Riviera-PRO | — |

Orden de compilación: `regmem_dut.sv apb_if.sv apb_pkg.sv regmem_ral_pkg.sv regmem_env_pkg.sv tb_top.sv`.

## Tests

| Test | Argumentos | Qué hace |
| --- | --- | --- |
| `model_check_test` | — | Punto de control del modelo: imprime direcciones y resets (Sección 7) |
| `predictor_test` | `+AUTO_PREDICT` opcional | Escritura sin el modelo; compara predicción explícita e implícita (8.5) |
| `ral_test` | `+STEP=1` … `+STEP=9` | Pasos del tutorial de accesos frontdoor y backdoor (10) |
| `builtin_test` | — | Secuencias predefinidas: rutas HDL, reset, bit bash y walk de memoria (11) |

Ejemplos:

```
make questa  TEST=ral_test ARGS="+STEP=3"
make vcs     TEST=ral_test ARGS="+STEP=8" DEFINES="+define+BUG_SCRATCH"
make xcelium TEST=predictor_test ARGS="+AUTO_PREDICT"
make questa  TEST=builtin_test
```

## Defines

| Define | Efecto |
| --- | --- |
| `BUG_SCRATCH` | Inyecta un error en el DUT: `SCRATCH` pierde el bit 31 al escribirse por el bus (pasos 8 y bit bash) |
| `NO_USER_BKDR` | No instala el backdoor de usuario: `SCRATCH` usa también el backdoor por rutas HDL (DPI) |

## Errores esperados

Algunos pasos provocan `UVM_ERROR` a propósito para enseñar algo; no son fallos de la solución:

- **Paso 2**: el segundo `mirror(UVM_CHECK)` falla porque `PRESCALER` se cambió por backdoor a espaldas del modelo.
- **Paso 3 d)**: leer `CMD` por backdoor falla porque no tiene ruta HDL.
- **Paso 9**: el último `mirror(UVM_CHECK)` falla porque `rm.reset()` solo resetea el modelo, no el DUT.
- **Paso 8 y `builtin_test`** con `BUG_SCRATCH`: detectan el error inyectado.
- **`predictor_test +AUTO_PREDICT`**: el `mirror` falla porque la predicción implícita no vio la escritura cruda.

## Requisitos de compilación

- UVM 1.2 o IEEE 1800.2 con DPI habilitado (no definir `UVM_HDL_NO_DPI`).
- Acceso de lectura y escritura a la jerarquía para el backdoor: `+acc` (Questa), `-debug_access+all` (VCS), `-access +rwc` (Xcelium), `+access +r+w` (Riviera-PRO). El Makefile ya los incluye.


