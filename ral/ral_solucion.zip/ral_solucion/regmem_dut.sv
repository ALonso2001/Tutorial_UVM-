// ============================================================================
// regmem_dut.sv
// Tutorial: el RAL de UVM desde cero - Sección 3
//
// Esclavo APB simplificado (sin estados de espera, pready = 1) con seis
// registros de 32 bits y una memoria de 32 palabras de 32 bits.
//
//   0x00 CTRL      EN[0] RW, MODE[2:1] RW, IRQ_EN[3] RW, PRESCALER[15:8] RW (reset 0x01)
//   0x04 STATUS    BUSY[0] RO, DONE[1] RO, ERR_CNT[11:4] RO
//   0x08 INT_STAT  DONE_IRQ[0] W1C, ERR_IRQ[1] W1C
//   0x0C CMD       OPCODE[3:0] WO (se lee como 0)
//   0x10 SCRATCH   DATA[31:0] RW
//   0x14 ID        VALUE[31:0] RO = 0x5A5A0001
//   0x80-0xFC BUF  32 x 32 bits RW
//
// Defina BUG_SCRATCH para inyectar un error: SCRATCH pierde el bit 31 al
// escribirse por el bus (Paso 8 del tutorial).
// ============================================================================
`timescale 1ns/1ps
module regmem_dut (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        psel,
  input  logic        penable,
  input  logic        pwrite,
  input  logic [7:0]  paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready,
  output logic        irq
);
  // ---------------- Almacenamiento ----------------
  // CTRL (un registro por campo, para practicar rutas HDL por trozos)
  logic        en_q;
  logic [1:0]  mode_q;
  logic        irq_en_q;
  logic [7:0]  presc_q;
  // STATUS
  logic        busy_q;
  logic        done_q;
  logic [7:0]  err_cnt_q;
  logic [2:0]  busy_cnt;
  // INT_STAT: bit 0 DONE_IRQ, bit 1 ERR_IRQ
  logic [1:0]  int_stat_q;
  // SCRATCH
  logic [31:0] scratch_q;
  // ID (constante)
  wire  [31:0] id_w = 32'h5A5A_0001;
  // Memoria BUF
  logic [31:0] mem [0:31];

  wire wr_en  = psel && penable && pwrite;
  wire is_mem = paddr[7];

  assign pready = 1'b1;
  assign irq    = irq_en_q && (|int_stat_q);

  // ---------------- Escritura de registros y comportamiento ----------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q       <= 1'b0;
      mode_q     <= 2'b0;
      irq_en_q   <= 1'b0;
      presc_q    <= 8'h01;
      busy_q     <= 1'b0;
      done_q     <= 1'b0;
      err_cnt_q  <= 8'h0;
      busy_cnt   <= 3'd0;
      int_stat_q <= 2'b0;
      scratch_q  <= 32'h0;
    end
    else begin
      // Operación en curso
      if (busy_q) begin
        if (busy_cnt == 3'd0) begin
          busy_q        <= 1'b0;
          done_q        <= 1'b1;
          int_stat_q[0] <= 1'b1;
        end
        else busy_cnt <= busy_cnt - 3'd1;
      end

      // Accesos de escritura del bus
      if (wr_en && !is_mem) begin
        case (paddr)
          8'h00: begin
            en_q     <= pwdata[0];
            mode_q   <= pwdata[2:1];
            irq_en_q <= pwdata[3];
            presc_q  <= pwdata[15:8];
          end
          8'h08: int_stat_q <= int_stat_q & ~pwdata[1:0];       // W1C
          8'h0C: if (en_q && pwdata[3:0] != 4'h0) begin
                   if (pwdata[3:0] == 4'hF) begin               // comando inválido
                     err_cnt_q     <= err_cnt_q + 8'd1;
                     int_stat_q[1] <= 1'b1;
                   end
                   else begin                                   // operación de 4 ciclos
                     busy_q   <= 1'b1;
                     done_q   <= 1'b0;
                     busy_cnt <= 3'd3;
                   end
                 end
`ifdef BUG_SCRATCH
          8'h10: scratch_q <= {1'b0, pwdata[30:0]};             // error inyectado: pierde el bit 31
`else
          8'h10: scratch_q <= pwdata;
`endif
          default: ;
        endcase
      end
    end
  end

  // ---------------- Escritura de memoria (sin reset) ----------------
  always_ff @(posedge clk)
    if (wr_en && is_mem) mem[paddr[6:2]] <= pwdata;

  // ---------------- Lectura ----------------
  always_comb begin
    prdata = 32'h0;
    if (psel && !pwrite) begin
      if (is_mem) prdata = mem[paddr[6:2]];
      else case (paddr)
        8'h00: prdata = {16'h0, presc_q, 4'h0, irq_en_q, mode_q, en_q};
        8'h04: prdata = {20'h0, err_cnt_q, 2'b00, done_q, busy_q};
        8'h08: prdata = {30'h0, int_stat_q};
        8'h0C: prdata = 32'h0;                                  // CMD es de solo escritura
        8'h10: prdata = scratch_q;
        8'h14: prdata = id_w;
        default: prdata = 32'h0;
      endcase
    end
  end
endmodule
