// ============================================================================
// apb_pkg.sv
// Tutorial: el RAL de UVM desde cero - Sección 4
//
// Agente APB: item, secuenciador, driver, monitor, agente y una secuencia
// cruda (sin RAL) que se usa para demostrar el predictor explícito.
// ============================================================================
`timescale 1ns/1ps
package apb_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // ------------------------------------------------------------ Item
  class apb_item extends uvm_sequence_item;
    rand bit        write;
    rand bit [7:0]  addr;
    rand bit [31:0] data;     // dato escrito, o dato leído tras la transferencia
    `uvm_object_utils_begin(apb_item)
      `uvm_field_int(write, UVM_DEFAULT)
      `uvm_field_int(addr,  UVM_DEFAULT)
      `uvm_field_int(data,  UVM_DEFAULT)
    `uvm_object_utils_end
    function new(string name = "apb_item"); super.new(name); endfunction
    virtual function string convert2string();
      return $sformatf("%s addr=0x%02h data=0x%08h", write ? "W" : "R", addr, data);
    endfunction
  endclass

  typedef uvm_sequencer #(apb_item) apb_sequencer;

  // ------------------------------------------------------------ Driver
  class apb_driver extends uvm_driver #(apb_item);
    `uvm_component_utils(apb_driver)
    virtual apb_if vif;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      if (!uvm_config_db #(virtual apb_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "apb_driver sin interfaz")
    endfunction

    task run_phase(uvm_phase phase);
      vif.psel    <= 1'b0;
      vif.penable <= 1'b0;
      wait (vif.rst_n === 1'b1);
      forever begin
        seq_item_port.get_next_item(req);
        @(posedge vif.clk);                       // ciclo de setup
        vif.psel    <= 1'b1;
        vif.penable <= 1'b0;
        vif.pwrite  <= req.write;
        vif.paddr   <= req.addr;
        vif.pwdata  <= req.write ? req.data : 32'h0;
        @(posedge vif.clk);                       // ciclo de access
        vif.penable <= 1'b1;
        @(posedge vif.clk);                       // fin de la transferencia (pready = 1)
        if (!req.write) req.data = vif.prdata;    // la respuesta vuelve en el propio item
        vif.psel    <= 1'b0;
        vif.penable <= 1'b0;
        seq_item_port.item_done();
      end
    endtask
  endclass

  // ------------------------------------------------------------ Monitor
  class apb_monitor extends uvm_monitor;
    `uvm_component_utils(apb_monitor)
    virtual apb_if vif;
    uvm_analysis_port #(apb_item) ap;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      ap = new("ap", this);
      if (!uvm_config_db #(virtual apb_if)::get(this, "", "vif", vif))
        `uvm_fatal("NOVIF", "apb_monitor sin interfaz")
    endfunction

    task run_phase(uvm_phase phase);
      forever begin
        @(posedge vif.clk);
        if (vif.psel && vif.penable && vif.pready) begin
          apb_item tr = apb_item::type_id::create("tr");
          tr.write = vif.pwrite;
          tr.addr  = vif.paddr;
          tr.data  = vif.pwrite ? vif.pwdata : vif.prdata;
          `uvm_info("APB", tr.convert2string(), UVM_MEDIUM)
          ap.write(tr);
        end
      end
    endtask
  endclass

  // ------------------------------------------------------------ Agente
  class apb_agent extends uvm_agent;
    `uvm_component_utils(apb_agent)
    apb_sequencer sqr;
    apb_driver    drv;
    apb_monitor   mon;
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      sqr = apb_sequencer::type_id::create("sqr", this);
      drv = apb_driver::type_id::create("drv", this);
      mon = apb_monitor::type_id::create("mon", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      drv.seq_item_port.connect(sqr.seq_item_export);
    endfunction
  endclass

  // ------------------------------------------------------------ Secuencia cruda
  // No pasa por el modelo de registros: sirve para demostrar el predictor.
  class apb_raw_write_seq extends uvm_sequence #(apb_item);
    `uvm_object_utils(apb_raw_write_seq)
    bit [7:0]  addr;
    bit [31:0] data;
    function new(string name = "apb_raw_write_seq"); super.new(name); endfunction
    task body();
      req = apb_item::type_id::create("req");
      start_item(req);
      req.write = 1'b1;
      req.addr  = addr;
      req.data  = data;
      finish_item(req);
    endtask
  endclass
endpackage
