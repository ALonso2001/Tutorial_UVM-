// ============================================================================
// tb_top.sv
// Tutorial: el RAL de UVM desde cero - Secciones 4 y 9.4
//
// Reloj, reset, interfaz APB, DUT y backdoor de usuario para SCRATCH.
// Defina NO_USER_BKDR para usar el backdoor por rutas HDL (DPI) también en
// SCRATCH.
// ============================================================================
`timescale 1ns/1ps
module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"
  // Estas importaciones no se usan directamente, pero obligan a elaborar los
  // paquetes: sin ellas, algunos simuladores no registran los tests en la fábrica.
  import apb_pkg::*;
  import regmem_env_pkg::*;

  logic clk = 1'b0;
  always #5 clk = ~clk;

  logic rst_n;
  initial begin
    rst_n = 1'b0;
    #22ns rst_n = 1'b1;
  end

  apb_if apb (.clk(clk), .rst_n(rst_n));

  regmem_dut dut (
    .clk    (clk),
    .rst_n  (rst_n),
    .psel   (apb.psel),
    .penable(apb.penable),
    .pwrite (apb.pwrite),
    .paddr  (apb.paddr),
    .pwdata (apb.pwdata),
    .prdata (apb.prdata),
    .pready (apb.pready),
    .irq    ()
  );

  // --------------------------------------------------------------------------
  // Backdoor de usuario para SCRATCH, por referencia jerárquica (Sección 9.4).
  // Se declara dentro del módulo para poder usar referencias jerárquicas.
  // --------------------------------------------------------------------------
  class scratch_bkdr extends uvm_reg_backdoor;
    function new(string name = "scratch_bkdr"); super.new(name); endfunction

    virtual task write(uvm_reg_item rw);
      do_pre_write(rw);                          // callbacks de usuario
      dut.scratch_q = rw.value[0][31:0];
      rw.status = UVM_IS_OK;
      `uvm_info("BKDR", $sformatf("write SCRATCH = 0x%08h", rw.value[0]), UVM_HIGH)
      do_post_write(rw);
    endtask

    virtual task read(uvm_reg_item rw);
      do_pre_read(rw);
      rw.value[0] = dut.scratch_q;
      rw.status   = UVM_IS_OK;
      `uvm_info("BKDR", $sformatf("read SCRATCH = 0x%08h", rw.value[0]), UVM_HIGH)
      do_post_read(rw);
    endtask
  endclass

  scratch_bkdr bk_scratch;

  initial begin
    uvm_config_db #(virtual apb_if)::set(null, "uvm_test_top.env.agt.*", "vif", apb);
`ifndef NO_USER_BKDR
    bk_scratch = new("bk_scratch");
    uvm_config_db #(uvm_reg_backdoor)::set(null, "uvm_test_top.env", "scratch_bkdr", bk_scratch);
`endif
    run_test();
  end
endmodule
