// ============================================================================
// apb_if.sv
// Tutorial: el RAL de UVM desde cero - Sección 4
// ============================================================================
`timescale 1ns/1ps
interface apb_if (input logic clk, input logic rst_n);
  logic        psel;
  logic        penable;
  logic        pwrite;
  logic [7:0]  paddr;
  logic [31:0] pwdata;
  logic [31:0] prdata;
  logic        pready;
endinterface
